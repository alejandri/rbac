

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">Permissions</h1>
</div>

<div class="card">
    <div class="card-header">
        <small class="text-muted">Permissions List Management</small> 
    </div>
    <div class="card-body p-2">

        <table class="table table-sm table-hover p-2">
                    <thead>
                    <tr>
                        <th scope="col" width="5%">#ID</th>
                        <th scope="col" width="25%">Permission Name</th>
                        <th scope="col" width="20%">Created</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                     
                            <tr>
                                <th scope="row"><?php echo e($permission->id); ?></th>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
      </table>

 


    </div>
</div>



 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rbac\resources\views/permissions/index.blade.php ENDPATH**/ ?>