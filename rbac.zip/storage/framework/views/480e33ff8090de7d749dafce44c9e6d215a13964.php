

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
  <h1 class="h2">Roles</h1>
</div>

<div class="card">
    <div class="card-header">
        <small class="text-muted">Roles List Management</small> 
    </div>
    <div class="card-body p-2">

        <table class="table table-sm table-hover p-2">
                    <thead>
                    <tr>
                        <th scope="col" width="5%">#ID</th>
                        <th scope="col" width="25%">Rol Name</th>
                        <th scope="col" width="25%">Permissions</th>
                        <th scope="col" width="20%">Created</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                     
                            <tr>
                                <th scope="row"><?php echo e($role->id); ?></th>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                <?php if($role->getPermissionNames()): ?>
                                  <?php $__currentLoopData = $role->getPermissionNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge badge-outline bg-secondary"> <?php echo e($permission); ?></span>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                                </td>

                                <td><?php echo e($role->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
      </table>

 


    </div>
</div>



 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rbac\resources\views/roles/index.blade.php ENDPATH**/ ?>