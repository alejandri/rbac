
    <div class="bg-light p-2 rounded">
        <h3>User</h3>
        <hr>

        <div class="container mt-4">
            <div>
                Name: <?php echo e($user->name); ?>

            </div>
            <div>
                Email: <?php echo e($user->email); ?>

            </div>
            <div>
                Roles: <?php echo e($user->getRoleNames()); ?>

            </div>
        </div>

    </div>
  
<?php /**PATH C:\laragon\www\rbac\resources\views/users/show.blade.php ENDPATH**/ ?>