

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Users</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_users')): ?>
        <button type="button" class="btn btn-sm btn-primary createButton" data-attr="<?php echo e(route('users.create')); ?>" 
            data-bs-toggle="modal" data-bs-target="#exampleModal">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>
            Add new user
        </button>                
    <?php endif; ?>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add new User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-sm btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <small class="text-muted">Usert List Management</small> 
    </div>
    <div class="card-body p-2">

        <table class="table table-sm table-hover p-2">
                    <thead>
                    <tr>
                        <th width="1%">#ID</th>
                        <th width="25%">Name</th>
                        <th>Email</th>
                        <th width="10%">Roles</th>
                        <th width="20%">Created</th>
                        <th width="5%"></th>    
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($user->id); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button type="button" class="btn btn-sm btn-secondary p-1">
                                                <?php echo e($role->name); ?>

                                            </button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div> 
                                </td>
                                <td><?php echo e($user->created_at); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_users')): ?>
                                        <button type="button" class="btn btn-sm btn-secondary p-1 createButton" class="btn btn-sm btn-primary" 
                                            data-attr="<?php echo e(route('users.show', $user->id)); ?>" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                            Show
                                        </button>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_users')): ?>
                                        <a type="button" class="btn btn-sm btn-secondary p-1" href="<?php echo e(route('users.edit', $user->id)); ?>">
                                            Edit
                                        </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_users')): ?>
                                        <a type="button" class="btn btn-sm btn-secondary p-1" href="<?php echo e(route('users.destroy', $user->id)); ?>" onclick="event.preventDefault();
                                            document.getElementById('delete-form-<?php echo e($user->id); ?>').submit();">
                                            Delete
                                        </a>
                                        <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('users.destroy', ['user' => $user])); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        </form>
                                    <?php endif; ?>
                                    </div>                     
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
    </table>

    <div class="d-flex">
        <?php echo $users->links(); ?>

    </div>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // display a modal (medium modal)
    $(document).on('click', '.createButton', function(event) {
        event.preventDefault();
        let href = $(this).attr('data-attr');
        $.ajax({
            url: href,
            beforeSend: function() {
                console.log('init modal')
            },
            // return the result
            success: function(result) {
                $('#exampleModal').modal("show");
                $('#exampleModal .modal-body').html(result).show();
            },
            complete: function() {
                console.log('end modal')
            },
            error: function(jqXHR, testStatus, error) {
                console.log(error);
            },
            timeout: 8000
        })
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\rbac\resources\views/users/index.blade.php ENDPATH**/ ?>