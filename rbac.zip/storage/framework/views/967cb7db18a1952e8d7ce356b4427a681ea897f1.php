<div class="container">

        <div class="bg-light">
          

            <div class="card">
                <div class="card-header">
                    <small class="text-muted"> Add new user and assign role.</small> 
                </div>
                <div class="card-body p-0">
           
                
                <div class="bg-white p-4 rounded">
  

        <div class="container">
        <form method="POST" action="<?php echo e(route('users.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input value="<?php echo e(old('name')); ?>" type="text" class="form-control" name="name" placeholder="Name" required>

                    <?php if($errors->has('name')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input value="<?php echo e(old('email')); ?>"
                        type="email" 
                        class="form-control" 
                        name="email" 
                        placeholder="Email address" required>
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <!-- <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input value="<?php echo e(old('username')); ?>"
                        type="text" 
                        class="form-control" 
                        name="username" 
                        placeholder="Username" required>
                    <?php if($errors->has('username')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                    <?php endif; ?>
                </div> -->

                <button type="submit" class="btn btn-primary">Save user</button>
               
            </form>
        </div>

    </div>

                
                </div>
            </div>


    

        </div>
  
    
  </div>

 



<?php /**PATH C:\laragon\www\rbac\resources\views/users/create.blade.php ENDPATH**/ ?>